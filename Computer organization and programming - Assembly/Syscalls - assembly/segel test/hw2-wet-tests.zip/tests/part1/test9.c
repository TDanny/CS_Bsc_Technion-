#include<stdio.h>
unsigned short count_above(char separator,long limit);
int main() {
	printf("%hu\n", count_above('a', 0));
	return count_above('a', 0);
}