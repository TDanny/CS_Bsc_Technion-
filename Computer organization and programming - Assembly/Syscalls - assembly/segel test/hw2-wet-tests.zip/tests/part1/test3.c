#include<stdio.h>
unsigned short count_above(char separator,long limit);
int main() {
	return count_above(',', 100);
}